#include<stdio.h>
#include "blink.h"
int main()
{
	blink();
	return 0;
}

