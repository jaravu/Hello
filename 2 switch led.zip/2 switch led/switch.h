int switches();

