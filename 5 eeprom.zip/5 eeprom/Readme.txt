EEPROM execution

./a.out phytec Engineer 0x10 0x30
